package FinacleIntegrator;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.sql.Date;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
// --- <<IS-END-IMPORTS>> ---

public final class wrapper

{
	// ---( internal utility methods )---

	final static wrapper _instance = new wrapper();

	static wrapper _newInstance() { return new wrapper(); }

	static wrapper _cast(Object o) { return (wrapper)o; }

	// ---( server methods )---




	public static final void datevalidator (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(datevalidator)>> ---
		// @sigtype java 3.5
		try{
			// Part-2 for Date Formatter
			Start start = new Start();
			DateFormatter dateformat = new DateFormatter(); // The class defined above
			String data = "26/11/1952"; // User \u2013 entered date. Given as an example here.
			// Calling the method of the Date Formatter class
			data = start.isNull(dateformat.setDisplayEffectiveDate(data));
			System.out.println("Valid Date data after formatting \u2013 "+data);
			}catch(Exception e)
			{
			System.out.println("Exception in main method-Start() :"+e);
			System.out.println("Please enter a valid date :");
			}
			}
			private String isNull(String string)
			{
			// Converts null value to a blank string
			if (string==null || "".equals(string.trim()) )
			{
			return " ";
			}
			return string.trim();
			}
			}
		
		
				
		// --- <<IS-END>> ---

                
	}
}

