package SIDBICrypto.services;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.InflaterOutputStream;
// --- <<IS-END-IMPORTS>> ---

public final class doubleEncryption

{
	// ---( internal utility methods )---

	final static doubleEncryption _instance = new doubleEncryption();

	static doubleEncryption _newInstance() { return new doubleEncryption(); }

	static doubleEncryption _cast(Object o) { return (doubleEncryption)o; }

	// ---( server methods )---




	public static final void doubleEncrypt (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(doubleEncrypt)>> ---
		// @sigtype java 3.5
		// [i] field:0:required plainText
		// [i] field:0:required sidbiPublicKey
		// [i] field:0:required idbiPrivateKey
		// [o] field:0:required encryptedText
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	plainText = IDataUtil.getString( pipelineCursor, "plainText" );
		String	sidbiPublicKey = IDataUtil.getString( pipelineCursor, "sidbiPublicKey" );
		String	idbiPrivateKey = IDataUtil.getString( pipelineCursor, "idbiPrivateKey" );
		pipelineCursor.destroy();
		
		String encryptedString=null;
		String encryptedStringWithPrivateKey=null;
		String errorMsg=null;
		
		try {
		encryptedString = encrypt(compressAndReturnB64(plainText), sidbiPublicKey).toString();
		encryptedStringWithPrivateKey = Base64.getEncoder().encodeToString(encryptWithPrivateKey(encryptedString, idbiPrivateKey));
		} catch (InvalidKeyException | BadPaddingException | IllegalBlockSizeException | NoSuchPaddingException
			| NoSuchAlgorithmException  | IOException e) {
		errorMsg=e.getMessage();
		} 
		
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "encryptedText", encryptedStringWithPrivateKey);
		if(errorMsg!=null) IDataUtil.put( pipelineCursor, "errorMsg", errorMsg );
		pipelineCursor_1.destroy();
		
			
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	
	//Extracting Public Key
	public static PublicKey getPublicKey(String base64PublicKey){
	PublicKey publicKey = null;
	try{
	    X509EncodedKeySpec keySpec = new X509EncodedKeySpec(Base64.getDecoder().decode(base64PublicKey.getBytes()));
	    KeyFactory keyFactory = KeyFactory.getInstance("RSA");
	    publicKey = keyFactory.generatePublic(keySpec);
	    return publicKey;
	} catch (NoSuchAlgorithmException e) {
	    e.printStackTrace();
	} catch (InvalidKeySpecException e) {
	    e.printStackTrace();
	}
	return publicKey;
	}
	
	//Extracting Private Key
	public static PrivateKey getPrivateKey(String base64PrivateKey){
	PrivateKey privateKey = null;
	PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(Base64.getDecoder().decode(base64PrivateKey.getBytes()));
	KeyFactory keyFactory = null;
	try {
	    keyFactory = KeyFactory.getInstance("RSA");
	} catch (NoSuchAlgorithmException e) {
	    e.printStackTrace();
	}
	try {
	    privateKey = keyFactory.generatePrivate(keySpec);
	} catch (InvalidKeySpecException e) {
	    e.printStackTrace();
	}
	return privateKey;
	}
	
	//Encrypting SIDBI Response with public key
	public static byte[] encrypt(String data, String publicKey) throws BadPaddingException, IllegalBlockSizeException, InvalidKeyException, NoSuchPaddingException, NoSuchAlgorithmException {
	Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
	cipher.init(Cipher.ENCRYPT_MODE, getPublicKey(publicKey));
	return cipher.doFinal(data.getBytes());
	}
	
	//Encrypting SIDBI Public Key Encrypted string with IDBI private key
	public static byte[] encryptWithPrivateKey(String dataPK, String privateKey) throws BadPaddingException, IllegalBlockSizeException, InvalidKeyException, NoSuchPaddingException, NoSuchAlgorithmException {
	Cipher cipherPK = Cipher.getInstance("RSA/ECB/PKCS1Padding");
	cipherPK.init(Cipher.ENCRYPT_MODE, getPrivateKey(privateKey));
	return cipherPK.doFinal(dataPK.getBytes());
	}
	
	public static byte[] compress(String text) throws IOException {
	return compress(text.getBytes());    }
	 
	public static byte[] compress(byte[] bArray) throws IOException {
	ByteArrayOutputStream os = new ByteArrayOutputStream();      
	try (DeflaterOutputStream dos = new DeflaterOutputStream(os)) {
	    dos.write(bArray);        }
	return os.toByteArray();    }
	
	
	public static String compressAndReturnB64(String text) throws IOException {
	return new String(Base64.getEncoder().encode(compress(text)));
	}
		
	// --- <<IS-END-SHARED>> ---
}

