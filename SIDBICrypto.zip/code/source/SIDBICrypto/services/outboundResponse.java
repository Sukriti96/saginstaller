package SIDBICrypto.services;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
// --- <<IS-END-IMPORTS>> ---

public final class outboundResponse

{
	// ---( internal utility methods )---

	final static outboundResponse _instance = new outboundResponse();

	static outboundResponse _newInstance() { return new outboundResponse(); }

	static outboundResponse _cast(Object o) { return (outboundResponse)o; }

	// ---( server methods )---




	public static final void decrypt_ (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(decrypt_)>> ---
		// @sigtype java 3.5
		// [i] field:0:required encryptedText
		// [o] field:0:required plainText
		// [o] field:0:optional errorMsg
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	encryptedText = IDataUtil.getString( pipelineCursor, "encryptedText" );
		pipelineCursor.destroy();
		
		String decryptedString=null;
		String errorMsg=null;
		
		try {
		    decryptedString = decrypt(encryptedText,sidbiPrivateKey);
		} catch (NoSuchAlgorithmException e) {
			errorMsg=e.getMessage();
		} catch (InvalidKeyException e) {
			errorMsg=e.getMessage();
		} catch (IllegalBlockSizeException e) {
			errorMsg=e.getMessage();
		} catch (BadPaddingException e) {
			errorMsg=e.getMessage();
		} catch (NoSuchPaddingException e) {
			errorMsg=e.getMessage();
		}
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "plainText", decryptedString );
		if(errorMsg!=null) IDataUtil.put( pipelineCursor, "errorMsg", errorMsg );
		pipelineCursor_1.destroy();		
		// --- <<IS-END>> ---

                
	}



	public static final void encrypt (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(encrypt)>> ---
		// @sigtype java 3.5
		// [i] field:0:required plainText
		// [o] field:0:required encryptedText
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	plainText = IDataUtil.getString( pipelineCursor, "plainText" );
		pipelineCursor.destroy();
		
		String encryptedString=null;
		String errorMsg=null;
		
		try {
			encryptedString = Base64.getEncoder().encodeToString(encrypt(plainText, sidbiPublicKey));
		} catch (InvalidKeyException | BadPaddingException | IllegalBlockSizeException | NoSuchPaddingException
				| NoSuchAlgorithmException e) {
			errorMsg=e.getMessage();
		}
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "encryptedText", encryptedString );
		if(errorMsg!=null) IDataUtil.put( pipelineCursor, "errorMsg", errorMsg );
		pipelineCursor_1.destroy();
		
			
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	private static String sidbiPublicKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAxMGvRjrB2ui0f+/sMmfVHPWhXloyzUybnlFUjqOtnDYXEAAqZGP9y5v3kC566CDnK/zZ/mZfwouZ8RS/+UWsqPX689zMl3PkeGZSGXmt7QvOdNCPp8038bXI7r8Wo+rurLqzXyIw5jIvRNw1gGh8Nu9QRaNZ/AM/yaKExWrKhMyWQHIzO6YPp0xx0cugTkJpZ3UmNzlLZ3dcLlhoToyJZix/VuJ7Ek5kjFs80QFJ+oZ2z4t4N0ehKeR5KFsWXnmRommvwMpV7AVo/CvQhtcVravrupWRKNaUJkmuhWPXOecLEDPyImAajk0qCIWE/CfqAeWjMZehthDogH7bLQrgvQIDAQAB";
	private static String sidbiPrivateKey = "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQDEwa9GOsHa6LR/7+wyZ9Uc9aFeWjLNTJueUVSOo62cNhcQACpkY/3Lm/eQLnroIOcr/Nn+Zl/Ci5nxFL/5Rayo9frz3MyXc+R4ZlIZea3tC8500I+nzTfxtcjuvxaj6u6surNfIjDmMi9E3DWAaHw271BFo1n8Az/JooTFasqEzJZAcjM7pg+nTHHRy6BOQmlndSY3OUtnd1wuWGhOjIlmLH9W4nsSTmSMWzzRAUn6hnbPi3g3R6Ep5HkoWxZeeZGiaa/AylXsBWj8K9CG1xWtq+u6lZEo1pQmSa6FY9c55wsQM/IiYBqOTSoIhYT8J+oB5aMxl6G2EOiAftstCuC9AgMBAAECggEBAKfgDdlhFrfdpuwl3CShvQ6pcVacpQ3PmFN7Vycg9mb7K7BGQ+VF/2xzFcYaMlnOgQ9h/Ol3larbC6zLpIRd81RyE/1v3cw3YK9ttgzwafqAAVZgAMIOcfY0wU0bE4kmUSBlZ9f6xzgRh408ShXWkG0awSW5m3RPnWQ/2wLJ/CNTII2JpZjeuO1a4NRobKrgA6HdEaQmlyiHke77ZyzkM8vcN/qeF/yziB9qDJ8Bf1PduZzccBdSotxRbSTBnBXsCaWC4cSmWz16eXyZrflRruUkJBiu2HEBrhry9lK1VtWQrS2H+j/yVk6TDM1K8mEVWfz+vjbDexVtOz2mu53N+00CgYEA58VLX07jJl/I2Pc2mL1dLygKti/PxLqnu0dE8uVwfJj77i1qcFikpNioewx6/ygYtDNX+Lt/6mjuaAr1CFJypNf1RV8s4eAxZx1W74Ski/Jol4Zo9JOPz2kJiPN52MdC4sw1nZoslDrFD4Hc8kBFCsEWMygXHJsm4979BnWfKqMCgYEA2VNVguIt/fVzUOyYpDQiEwImx0i82SDNJR+et9D0mdjLoJdgtWNl4wOS1mIUJY7otLjE3G+j1DlTYeo3IP+UDOZhIqptKIGlLUo1Tqb5NpUwvq9Ji58a9YWWnT76BjxdOmrSEtgbUrdsDRnixwtiMR+wKuBU4GP8ThRoHlKS3R8CgYA98tkTj3Vdc2quu10HdE3s5cn/KkZhcfaVMxZ1yefIFef4oID7qGXRfeuCgDJ78s6vk62m2Q72q7dVbeBSqh7keqifMzI+6Xqq8gejm5OTqGZWYeG5xZtBt/SJe3KNA62YCzcleekCcbbsTyysP4t0tWlmoQeUaM/7RkXhLR0u+wKBgDbZ5qJDLfKEKdfJ73i6Q8NibqErxaZTthNhmLCyR5ow8qwUqO7/KG8UrtH3LTiRikBaxi0Q7FubIGV9NO7aMubSmr+iHiz0E9mLekrgr9PL8eKe4UQhIy/GyM3lYDuErs8YuO7SporJCrd/yhIM2HqnkdIwjpuYAM1AL0s/8htnAoGAJ7kBVonKe5vTzUr8zleD7OR+NdtEed9TFBQW/YX+tZVoiNgsGItzkIHT85K8+nbrRLSdHmho1uqUkpT2smTk2JCUwZqBivmWhcx2XqHmBgz7R+F0hWdN/CyzN3qKXX0yq4brlvAyQ+I0OUVhiVr+BQBT3qwipA71s2nI0XYpy/0=";
	private static String idbiPublicKey ="MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAqAWkAhjW6JhpmJiV1JH8JpOSqN5fOhJ3v0gNrGwKay2KKP/EDNsnwnrIZrqT3uaWjo8C7MkbW/Sl00sEy/D/Agx+QmvU4bFOpJUZXywQNpp9jDIBJT1eFWGfVRtAGPh9JvEwQ98+WauHnO6ANnG1cMNU/akDQksZ7fRS/OHdLMclY0WXpXBbYgWZRVIQ2LAvESt33w6KWrYWu4juE7oWtYQSwHYx8LVa3qXtgmwJNZOa1rr9T+6Rpi6LEuUiBO3B64yT/Py4Lxn4LU2DSCb3a46QUrSqY4Tt/KPP0zt6RL9CPXyR8KRGwy+Si7cX2F6x2u+4S5FDdI4fxTPjVEtPFTD8sjL/e/7aiGtUS2PSX8KQJUXfVa86xUkz3mCcLWz+JLN5pbCiS4NrhqMsBitlRt2JMK8I5/SdrvTPYmSQ1q/+mClX3gHqFLkMUfLmbN/dXUTovjPK40DkmKdl9OWNemMeGR7jU2wDWVkPJC47iX2xADARscK5OekzXiC65F8sxgM8cfNhkvLkgg7UdgST8Pt5k3AzfJy4rQftU2Vs7s7KhG7WN+KZkDn9W9HZ4S4ctG2wIHUgBTcCRhVUk7hX43b06h/n9jjCmjICLftPZuEJJpSEKPXx1is9/NOrEcCwSYPm3YOeSX8fM/6xNjVYUOezUdxsul9BHmUJXBVQUeUCAwEAAQ==";
	private static String idbiPrivateKey ="al8AvX4On8sSqXMaUfOpkV/V02O/Wjd7QReYumCbsrHsb7nYxkV+6sXfw6kZCW8yX2fm1CV+FxJRvqYx3F7dHvQkDDBFKXeXkEmSC5NaF5hOIYiblPts986AW2WCsrTZ/L/swTY2TAVHowMaGBKyaeHV7DM/7St1hyH1n40e5dvPY1gaSSKwCeNTppsp8oKjiMZMGBqN3tvitlS3fjTEwoPc+mnmgWo+IXtzvNSP8xU6rSDl6QymLhZD4yKDoj2qO3yzhTQMtCYAVWlgrz8G/egDSbJhm0FsMV+Ne5rnyh23I+jmo8MNkgTWSEvSxa37X9ZFEDaVkd3onnEsBzV0KpeE8b4txveKAPcBSkmAGiUrbJSS+N9cToz5QM+hMkh6+Lp1wNHsDgK5RTcIbracb2Z2JjSoJhpqLqTK86pe80kzGgqvIzvVPoGz0URYuIHhTM/OT+NVA7BteeM2HEhLgSqdOYjs0qvBwtfyfLYmgSEnnQnfonlA4Azy3s3sbGKyd7iy2tYFsWfM3WlNLBdTRDcwcXzC6OMgN/QP+jv+AvHkvh1BrXjJeYdKFyN9RncCtV06zuJ6Nv0wZC9LnVhMxusKo2wJaSxLmXYSsYrpa9kaqtqcEzz1m4NsCDgp/RgQIVfLsDf4UVmPtNHMkdWNEgKGGU/byK4TgLwt3/rjKNtaRFH5vVgpCsYbgYPRLQzOQbWWhVe5gn22S0VULQ3yhbad/FxgNZlOXc4fFWbl+inFWYQAhwzEeGhrGinqz+IeiptIfUSqjEclPcPjq1+qVowpEn/siQg4WVFsMk0hkdHFD84YuKHGvoQAzzzr2egZd+CZm3iUlsvKy+JPAajKZVSAGA9mt4MJF/oJ4Jv5cxtJGl+8PwU1p6F1YTzWJ6FoBCLasR8UakIGO+vvXiWoCuw2tBFRCatieC3FT8l376PldvLDXXuhjFJdRZdi05rQJG+oE5cQj33azjemFck5eCF5AggGpODlEV9qA+Gl+S0WjSCz1zEFdwHGY+n/2BfssKUpZSewsXANUThrOw33vnAUTomI6kLdLHsYhS1dX6/x8vltXcg8Mk/aLcD8trT2DhN9mtXZ7kr8Ut3HbHImkLKTPUsUyCub2ZmdB77Klj+bKzaCasNjPpr6kHMIY9tepsq6zt5xdm9FEOQ6VZTorGT/1/vhfNIoIsOpKkAE6YCEGKlJw3I28lIW4NnCKBB5UCIt+hZlVMx1d23BV/tlM+7LRKt1lrFPyKpfJebeU3/gO3qtbaef3u8uEMar1Sih1IqCFsxZ+dH2jPoNQ+tXVMV1HWTm3ZoeI6qJNrTSsKidxu/vgXaarsh0rggR0iyA5SW9jlVG8MZ5DBEYvE2WsZlPovBD6m2Z9bwldv6Cp+y5wg3VFfxKbvgPh5xZsx4gLBjcCkfUsav0QyKxa7sMitfEYEKonEhWWxt8OT/ZV9cT4Csq9yVnltEkGoa/63UEma6gN/U7XMjqIeEVuN/8YrVCD8g4p1gaOpaqHYuCwgIvtPUBxd7YMJdYR8er1IUlpX8h85a1GaEVXJPpUs33AfTHJ4xj0AlDVMAM9o1X97oJaEgYN5GatTqHaOP15OKmHLYkPMtU/3vvUfkxSv0qjrEyGHsDUUYsAwHpheKco2UTagpFylNOGjkobz+HiSpRaNmkNIaRl30Jy/wDUYyCsTj4x082TM5qBemUB37frYVOQWetSW+K+GO4FkB+Ws1qLf5ylxng/5ijOPO7y2B84pG34bbKjXojnV1DcPI2gEYznL3D2AVFLajXVNX58DnZyQ+ETpZp7E4reydSD2M3oJDkBzJtexBAyh6XOCwYzQjOKdWlanQRRGbOZiRj7kG7D33UWWA2HyovniAvL4xqUYg0TTLTxn+dZ3kmKpimxqNm97sGt973QShCRltmSJnLK3+hqnCKvy6BMGpsF6HQYaj/0h4ol4ACOsvlii76SFrQK461AsfKJgfPbFl/u3VhxqUknsKpzWQ/jjGnXXHACPsiRkHnHE8fh6HYn6S8p+qrlwLXUg3L+9RLxWRSA+zVoBJj8CSx2TgYNtc/WLPqRWEQGe/ojpziqURdYR4mwkIQg1thlfnB3EPu9OC4rxusJLJaHIrphw9Rhp700uBzKVSS5dKSFyHy4Vg1s5Au5ibJks4gmP+2SwVWGKn10tI/eKdbUi/zNs7jzcEtOW3p5P089M64VLsBZJjhBw0KWD6UnM0KegWoPinWo9qjZfog3OC/6aut9ef6AWlt70a+r7OqLgvPgZWKy6tmGGw/nTGO+dRYdRKIzMQCkxrt3y5PMYynfd3ffwM5Lziz5SPNAkMVeBBzRdPHJCLbbKWayUgauegRg5JMBrzVa/OblDzO2q9KQ4Zh3FzN3pEClERFjRNadwqtc/CoFo3+iWCqCgeAXkWOLKokBlE/Whi5CN7Noa+exDbMGTm4qemysVslL58l2vbQikROU4Aez2nHjRXrubiGmQhfiOF4bCLxx7YOGiRbAko75z9OnL5brWBS14HcdtzTmBb5NW330Nj/AvLtzHUVvmHw5SHXrKgmEl5bECuSeeO+V9NAd7yUlvbcgGKdtKbUKJ+T7osjkqHfVQRv2cl2pqToUElDBIpzvGggzTnYIyK8bxc5Iy0+VqbW7jLv95psU/bO5WE6KmgVettEqF7kJSiGZfuZ8pxG5nL+uwpclda5N2ymR4icPSfqrGaV9eTOaWD3zpNWt/AgYy+ns83mI6fGBFzHlP8qNBnEy3VemRE1zn52wUx7qUJb9I5tGa8SFXbrh3qIqhojV0A94+QmZh2XO6YsmGtP7TqF0caoOMQNZ7fMj0Hj0pN11ywdymbhTGIjWE4ktAHxm56sRcxKugFieXhH8Sv5QlYj/g9R8B0bTmC8rZ7ryJZKc4NY36dJqq4M3VuYcAqDOhln16epKBjGja9zDADEE3n2OuWgQedkpc3y3zIEPNC1Imabu/1+xqVcBwNSOrBVRcUV/NkzYb8r+tNJodUB7M5xPqYfUGu5Pci4y/bn6hnrg68ekrsBRKpCgfrTpw+0ACBYW2x/zuyiKx4OiYicgLpDiXAkI4LvfrFMIDFCngc+jQXNze8ey63q3AT7zJ6XTCDwPnVkzGHli1faA5ElTm0H";
		
	//Extracting Public Key
	public static PublicKey getPublicKey(String base64PublicKey){
	    PublicKey publicKey = null;
	    try{
	        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(Base64.getDecoder().decode(base64PublicKey.getBytes()));
	        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
	        publicKey = keyFactory.generatePublic(keySpec);
	        return publicKey;
	    } catch (NoSuchAlgorithmException e) {
	        e.printStackTrace();
	    } catch (InvalidKeySpecException e) {
	        e.printStackTrace();
	    }
	    return publicKey;
	}
	
	//Extracting Private Key
	public static PrivateKey getPrivateKey(String base64PrivateKey){
	    PrivateKey privateKey = null;
	    PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(Base64.getDecoder().decode(base64PrivateKey.getBytes()));
	    KeyFactory keyFactory = null;
	    try {
	        keyFactory = KeyFactory.getInstance("RSA");
	    } catch (NoSuchAlgorithmException e) {
	        e.printStackTrace();
	    }
	    try {
	        privateKey = keyFactory.generatePrivate(keySpec);
	    } catch (InvalidKeySpecException e) {
	        e.printStackTrace();
	    }
	    return privateKey;
	}
	
	//Encrypting SIDBI Response
	public static byte[] encrypt(String data, String publicKey) throws BadPaddingException, IllegalBlockSizeException, InvalidKeyException, NoSuchPaddingException, NoSuchAlgorithmException {
	    Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
	    cipher.init(Cipher.ENCRYPT_MODE, getPublicKey(publicKey));
	    return cipher.doFinal(data.getBytes());
	}
	
	//Decrypting SIDBI Request
	public static String decrypt(byte[] data, PrivateKey privateKey) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException {
	    Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
	    cipher.init(Cipher.DECRYPT_MODE, privateKey);
	    return new String(cipher.doFinal(data));
	}
	
	public static String decrypt(String data, String base64PrivateKey) throws IllegalBlockSizeException, InvalidKeyException, BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException {
	    return decrypt(Base64.getDecoder().decode(data.getBytes()), getPrivateKey(base64PrivateKey));
	}
	// --- <<IS-END-SHARED>> ---
}

