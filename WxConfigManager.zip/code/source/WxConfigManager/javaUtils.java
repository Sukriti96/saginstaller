package WxConfigManager;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.app.b2b.server.Server;
import com.wm.lang.ns.NSPackage;
import com.wm.lang.ns.NSService;
import com.wm.lang.ns.Namespace;
import com.wm.lang.ns.NSName;
import com.wm.lang.ns.NSNode;
import com.softwareag.is.svc.Pipeline;
import com.softwareag.util.IDataMap;
import java.io.*;
import java.util.*;
// --- <<IS-END-IMPORTS>> ---

public final class javaUtils

{
	// ---( internal utility methods )---

	final static javaUtils _instance = new javaUtils();

	static javaUtils _newInstance() { return new javaUtils(); }

	static javaUtils _cast(Object o) { return (javaUtils)o; }

	// ---( server methods )---




	public static final void addCommonConfig (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(addCommonConfig)>> ---
		// @sigtype java 3.5
		// [i] field:0:required configFileName
		// [i] field:0:required key
		// [i] field:0:required value
		// [o] field:0:required commonConfigAddStatus
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	configFileName = IDataUtil.getString( pipelineCursor, "configFileName" );
			String	key = IDataUtil.getString( pipelineCursor, "key" );
			String	value = IDataUtil.getString( pipelineCursor, "value" );
		pipelineCursor.destroy();
		
		//Initializing Variables	
			String	configFilePath = CONFIG_DIR.concat(configFileName).concat(".cnf");
			boolean completed;
			String configAdditionStatus="FAILURE";
			
		//Business Logic
		properties = new Properties();
		try{
			properties.load(new FileInputStream(configFilePath));
			properties.put(key, value);
			FileOutputStream output = new FileOutputStream(configFilePath);
			properties.store(output, "This is a modified version of auto-generated file for this package");
			completed=true;
		}catch(Exception e){
			e.printStackTrace();
			completed=false;
		}
		
		if(completed==true) configAdditionStatus="SUCCESS";
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "commonConfigAddStatus", configAdditionStatus);
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void addConfig (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(addConfig)>> ---
		// @sigtype java 3.5
		// [i] field:0:required configFilePath
		// [i] field:0:required key
		// [i] field:0:required value
		// [o] field:0:required configAddStatus
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	configFilePath = IDataUtil.getString( pipelineCursor, "configFilePath" );
			String	key = IDataUtil.getString( pipelineCursor, "key" );
			String	value = IDataUtil.getString( pipelineCursor, "value" );
			boolean completed;
			String configAdditionStatus="FAILURE";
		pipelineCursor.destroy();
		properties = new Properties();
		try{
			properties.load(new FileInputStream(configFilePath));
			properties.put(key, value);
			FileOutputStream output = new FileOutputStream(configFilePath);
			properties.store(output, "This is a modified version of auto-generated file for this package");
			completed=true;
		}catch(Exception e){
			e.printStackTrace();
			completed=false;
		}
		
		if(completed==true) configAdditionStatus="SUCCESS";
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "configAddStatus", configAdditionStatus);
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void checkConfigExistence (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(checkConfigExistence)>> ---
		// @sigtype java 3.5
		// [i] field:0:required filePath
		// [o] field:0:required isExist
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	filePath = IDataUtil.getString( pipelineCursor, "filePath" );
		pipelineCursor.destroy();
		
		File tempFile = new File(filePath);
		boolean exists = tempFile.exists();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "isExist", String.valueOf(exists));
		pipelineCursor_1.destroy();
		
		
			
		// --- <<IS-END>> ---

                
	}



	public static final void createCommonConfigFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(createCommonConfigFile)>> ---
		// @sigtype java 3.5
		// [i] field:0:required configFilePath
		// [o] field:0:required configCreationStatus
		// [o] field:0:required configFilePath
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	configFilePath = IDataUtil.getString( pipelineCursor, "configFilePath" );	
		pipelineCursor.destroy();
		
		//Initializing Variables
		boolean completed=false;
		String commonConfigCreationStatus="FAILURE";
		
		//Business Logic
			try{			
			// write to the file stream and convert it to a properties object	
			FileOutputStream configFileOutputStream=new FileOutputStream(configFilePath);
			
			// properties object is already defined in the Shared code
			properties = new Properties();
			properties.store(configFileOutputStream, "This is a fresh version of auto-generated file");
			completed=true;
			}catch ( Exception e ){
				completed=false;
			 throw new ServiceException("Error while registering "+configFilePath+".cnf property file: "+e);
			}		
		
		if(completed==true) commonConfigCreationStatus="SUCCESS";
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "commonConfigCreationStatus", commonConfigCreationStatus );
		IDataUtil.put( pipelineCursor_1, "configFilePath", configFilePath );
		pipelineCursor_1.destroy();		
		// --- <<IS-END>> ---

                
	}



	public static final void createConfigFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(createConfigFile)>> ---
		// @sigtype java 3.5
		// [i] field:0:required packageName
		// [i] field:0:required configFilePath
		// [o] field:0:required configCreationStatus
		// [o] field:0:required configFilePath
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	packageName = IDataUtil.getString( pipelineCursor, "packageName" );
			String	configFilePath = IDataUtil.getString( pipelineCursor, "configFilePath" );
		pipelineCursor.destroy();
		boolean completed=false;
		String configCreationStatus="FAILURE";
		
			try{			
			// write to the file stream and convert it to a properties object	
			FileOutputStream configFileOutputStream=new FileOutputStream(configFilePath);
			
			// properties object is already defined in the Shared code
			properties = new Properties();
			properties.store(configFileOutputStream, "This is a fresh version of auto-generated file");
			completed=true;
			}catch ( Exception e ){
				completed=false;
			 throw new ServiceException("Error while registering "+packageName+".cnf property file: "+e);
			}		
		
		if(completed==true) configCreationStatus="SUCCESS";
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "configCreationStatus", configCreationStatus );
		IDataUtil.put( pipelineCursor_1, "configFilePath", configFilePath );
		pipelineCursor_1.destroy();		
		// --- <<IS-END>> ---

                
	}



	public static final void deleteCommonConfig (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(deleteCommonConfig)>> ---
		// @sigtype java 3.5
		// [i] field:0:required configFileName
		// [i] field:0:required key
		// [o] field:0:required configDeletionStatus
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	configFileName = IDataUtil.getString( pipelineCursor, "configFileName" );
			String	configFilePath = CONFIG_DIR.concat(configFileName).concat(".cnf");
			String	key = IDataUtil.getString( pipelineCursor, "key" );
			boolean completed=false;
			String configDeletionStatus="FAILURE";
		pipelineCursor.destroy();
		properties = new Properties();
		try{
		properties.load(new FileInputStream(configFilePath));
		properties.remove(key);
		FileOutputStream output = new FileOutputStream(configFilePath);
		properties.store(output, "This is a modified version of auto-generated file");
		completed=true;
		}catch(Exception e){
			e.printStackTrace();
			completed=false;
		}
		
		if(completed==true) configDeletionStatus="SUCCESS";
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "configDeletionStatus", configDeletionStatus);
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void deleteConfig (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(deleteConfig)>> ---
		// @sigtype java 3.5
		// [i] field:0:required configFilePath
		// [i] field:0:required key
		// [o] field:0:required configDeletionStatus
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	configFilePath = IDataUtil.getString( pipelineCursor, "configFilePath" );
			String	key = IDataUtil.getString( pipelineCursor, "key" );
			boolean completed=false;
			String configDeletionStatus="FAILURE";
		pipelineCursor.destroy();
		properties = new Properties();
		try{
		properties.load(new FileInputStream(configFilePath));
		properties.remove(key);
		FileOutputStream output = new FileOutputStream(configFilePath);
		properties.store(output, "This is a modified version of auto-generated file");
		completed=true;
		}catch(Exception e){
			e.printStackTrace();
			completed=false;
		}
		
		if(completed==true) configDeletionStatus="SUCCESS";
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "configDeletionStatus", configDeletionStatus);
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void deleteConfigFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(deleteConfigFile)>> ---
		// @sigtype java 3.5
		// [i] field:0:required configFilePath
		// [o] field:0:required configFileDeletionStatus
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	configFilePath = IDataUtil.getString( pipelineCursor, "configFilePath" );
			boolean status = false;
			String configFileDeletionStatus="FAILURE";
		pipelineCursor.destroy();
		File myConfigFile=new File(configFilePath);
		if(myConfigFile.delete()){
			status=true;
		}else{
			status=false;
		}
		if (status==true) configFileDeletionStatus="SUCCESS";
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "configFileDeletionStatus", configFileDeletionStatus );
		pipelineCursor_1.destroy();
		
			
		// --- <<IS-END>> ---

                
	}



	public static final void formConfigFilePath (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(formConfigFilePath)>> ---
		// @sigtype java 3.5
		// [i] field:0:optional packageName
		// [i] field:0:optional commonConfigFileName
		// [i] field:0:required env {"dev","sit","uat","prod"}
		// [o] field:0:required configFilePath
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	packageName = IDataUtil.getString( pipelineCursor, "packageName" );
			String	commonConfigFileName = IDataUtil.getString( pipelineCursor, "commonConfigFileName" );
			String	env = IDataUtil.getString( pipelineCursor, "env" );
		pipelineCursor.destroy();
		String configFilePath=null;
		
		if(commonConfigFileName!=null) configFilePath=CONFIG_DIR.concat(commonConfigFileName).concat("-").concat(env).concat(".cnf");
		else configFilePath=CONFIG_DIR.replace("WxConfigManager",packageName).concat(packageName).concat("-").concat(env).concat(".cnf");
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "configFilePath", configFilePath);
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getConfig (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getConfig)>> ---
		// @sigtype java 3.5
		// [i] field:0:required key
		// [o] field:0:required value
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	key = IDataUtil.getString( pipelineCursor, "key" );
		pipelineCursor.destroy();
		
		// check to see if properties object is null
		   if (properties == null)
		   {
		    loadProperties( null );
		   }
		   
		   String value = getProperty(key);
		
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value );
		pipelineCursor_1.destroy();
		
			
		// --- <<IS-END>> ---

                
	}



	public static final void loadProperties (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(loadProperties)>> ---
		// @sigtype java 3.5
		// [i] field:0:required filename
		 /*
		Retrieves values from configFile
		directory [server]/packages/yourPackage/config/
		*/
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	filename = IDataUtil.getString( pipelineCursor, "filename" );
		pipelineCursor.destroy();
		
		// pipeline
		
		try{
		 // read in the file stream and convert it to a properties object
		FileInputStream configFileInputStream = new FileInputStream( filename );
		
		 // properties object is already defined in the Shared code
		properties = new Properties();
		properties.load( configFileInputStream );
		propertiesLoaded = true;
		
		}catch ( FileNotFoundException e ){
		// throw an error
		 throw new ServiceException("Error finding property file: "+e);
		}catch ( IOException e ){
		//throw an error
		 throw new ServiceException("Error reading "+CONFIG_FILE+" property file: "+e);
		}catch ( Exception e ){
		//throw an error
		 throw new ServiceException("Error while registering "+CONFIG_FILE+" property file: "+e);
		}
			
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	// initialize static variables
	private static String CONFIG_DIR ="packages/WxConfigManager/config/";
	private static String CONFIG_FILE = CONFIG_DIR+"<filename>"+".cnf";		 
	private static boolean propertiesLoaded = false;
	private static Properties properties = null;
		 
	
	
	/** gets a property from the configuration file **/
	public static String getProperty( String key ) throws ServiceException
	{
	// check to see if the properties have been loaded
	if (!propertiesLoaded) {
		    try{
		     IData idata = IDataFactory.create();
		     IDataUtil.put(idata.getCursor(),"configFile",CONFIG_FILE);
		              loadProperties( idata );
		    }catch (Exception e){
		     throw new ServiceException("Failed to load properties:"+e.toString());
		    }
		 }
	if ( properties == null )
		  return( null );
	else
		  return( properties.getProperty( key ) );
	}
	
	/** gets filepath of a configuration file **/
	public static String getConfigFile( String key ) throws ServiceException
	{
	// check to see if the properties have been loaded
	if (!propertiesLoaded) {
		    try{
		     IData idata = IDataFactory.create();
		     IDataUtil.put(idata.getCursor(),"configFile",CONFIG_FILE);
		              loadProperties( idata );
		    }catch (Exception e){
		     throw new ServiceException("Failed to load properties:"+e.toString());
		    }
		 }
	if ( properties == null )
		  return( null );
	else
		  return( properties.getProperty( key ) );
	}
	
		
	// --- <<IS-END-SHARED>> ---
}

