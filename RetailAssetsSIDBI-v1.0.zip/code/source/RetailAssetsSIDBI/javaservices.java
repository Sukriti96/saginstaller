package RetailAssetsSIDBI;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.util.JournalLogger;
// --- <<IS-END-IMPORTS>> ---

public final class javaservices

{
	// ---( internal utility methods )---

	final static javaservices _instance = new javaservices();

	static javaservices _newInstance() { return new javaservices(); }

	static javaservices _cast(Object o) { return (javaservices)o; }

	// ---( server methods )---




	public static final void javaservicceinvoke (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(javaservicceinvoke)>> ---
		// @specification pub.apigateway.invokeISService.specifications:ResponseSpec
		// @sigtype java 3.5
		IDataCursor idc = pipeline.getCursor();
		//MessageContext context = (MessageContext)IDataUtil.get(idc,"MessageContext");
		JournalLogger.log(4,90,4,"[MY.APP.LOG]","log is"+IDataUtil.get(idc,"MessageContext").toString());
			
		// --- <<IS-END>> ---

                
	}
}

