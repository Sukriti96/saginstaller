package idbi.commonutils.pub.service;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.net.InetAddress;
import java.net.UnknownHostException;
import com.wm.util.Debug;
import java.io.*;
import java.util.*;
import java.lang.System;
import com.wm.app.b2b.server.*;
import com.wm.util.Table;
import java.text.*;
import com.wm.lang.ns.*;
// --- <<IS-END-IMPORTS>> ---

public final class system

{
	// ---( internal utility methods )---

	final static system _instance = new system();

	static system _newInstance() { return new system(); }

	static system _cast(Object o) { return (system)o; }

	// ---( server methods )---




	public static final void getPckgSvcName (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getPckgSvcName)>> ---
		// @sigtype java 3.5
		// [o] field:0:required packageName
		// [o] field:0:required serviceName
		IDataCursor cursor = pipeline.getCursor();
		com.wm.lang.ns.NSService nsService = Service.getCallingService();
		IDataUtil.put(cursor, "packageName", nsService.getPackage().toString().substring(4));
		IDataUtil.put(cursor, "serviceName", nsService.toString());
		 
		// pipeline
		
		cursor.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getServerInformation (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getServerInformation)>> ---
		// @sigtype java 3.5
		// [o] field:0:required serverName
		// [o] field:0:required primaryPort
		// [o] field:0:required currentPort
		IDataCursor idcPipeline = pipeline.getCursor();  
		
		String strServerName = ServerAPI.getServerName();
		int intCurrentPort = ServerAPI.getCurrentPort();
		
		IData listenerInfo = null;
		Integer intPrimaryPort = null; 
		
		try
		{
		  IData results = Service.doInvoke("wm.server.net.listeners", "getPrimaryListener", pipeline);
		  IDataUtil.merge(results, pipeline);
		
		}
		catch (Exception e)
		{
		  throw new ServiceException("Could not invoke wm.server.net.listeners:getPrimaryListener: " + e);
		}
		
		if (idcPipeline.first("primary"))
		{
		  listenerInfo = (IData) idcPipeline.getValue();
		  idcPipeline.delete();
		}
		IDataCursor idcListenerInfo = listenerInfo.getCursor();
		
		if (idcListenerInfo.first("port"))
		{
		  intPrimaryPort = (Integer) idcListenerInfo.getValue();
		}
		
		idcPipeline.insertAfter("serverName", strServerName);
		idcPipeline.insertAfter("primaryPort", intPrimaryPort.toString());
		idcPipeline.insertAfter("currentPort", Integer.toString(intCurrentPort));
		
		// Clean up IData cursors
		idcListenerInfo.destroy();
		idcPipeline.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getServerProperties (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getServerProperties)>> ---
		// @sigtype java 3.5
		// [o] field:0:required env
		// [o] field:0:required homeDir
		IDataCursor cursor = pipeline.getCursor();
		IDataUtil.put(cursor, "env", System.getProperty("watt.server.idbi.environment"));
		IDataUtil.put(cursor, "homeDir", System.getProperty("watt.server.homeDir"));
		// --- <<IS-END>> ---

                
	}



	public static final void searchString (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(searchString)>> ---
		// @sigtype java 3.5
		// [i] field:0:required text
		// [i] field:0:required searchString
		// [o] field:0:required isFound
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	text = IDataUtil.getString( pipelineCursor, "text" );
			String	searchString = IDataUtil.getString( pipelineCursor, "searchString" );
		pipelineCursor.destroy();
		Boolean isFound1=text.contains(searchString);
		String isFound=isFound1.toString();
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "isFound", isFound );
		pipelineCursor_1.destroy();
		
			
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	/**
	 * Used by "deepConvert"
	 * 
	 */
	private static final Values convert(Hashtable hT)
	{
	  // Following statement gets all arrays in this object.
	  boolean nullFlag = false;
	  Object[] hTArray = hT.values().toArray();
	  Enumeration hTEnumeration = hT.keys();
	  Values outbound = new Values();
	
	  for (int i = 0; i < hTArray.length; i++)
	  {
	    String key = (String) hTEnumeration.nextElement();
	    if (hTArray[i] instanceof java.lang.String)
	    {
	      outbound.put(key, (String) hTArray[i]);
	    }
	    else if (hTArray[i] instanceof java.util.Hashtable)
	    {
	      Values internalObject = convert((Hashtable) hTArray[i]);
	      if (internalObject == null)
	      {
	        nullFlag = true;
	        return null;
	      }
	      outbound.put(key, internalObject);
	    }
	    else
	    {
	      System.out.println("Conversion Failure:" + "unsupported type within inbound Hashtable.");
	      return null;
	    }
	  }
	  return outbound;
	} 
	
	public static final int MAXSLEEP = 3600000; // one hr
		
	// --- <<IS-END-SHARED>> ---
}

